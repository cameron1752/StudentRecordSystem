/*
 * Database.java
 *
 */
import java.util.*;
import java.io.*;
import java.sql.*;
import javax.swing.*;


//Database Class
public class Database {
    
//Declaration of variables    
String filePath = "jdbc:ucanaccess://C:/My_Documents/Spring2020/IST411/JDBC_XML_LIST_Examples/Student_XML_JDBC_App/StudentRegistration.accdb";
//createTable() drops the current table and creates a new one
    public void createTable() {
        
       try
        {
             // load database driver class
         Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

           
         // connect to database
         Connection con = DriverManager.getConnection(filePath);
         Statement stmt = con.createStatement();
         
         //this code may need to be commented out because an exception will be thrown
         //if this table doesn't exist in the database
         stmt.execute("DROP TABLE Students");
         
         stmt.execute("CREATE TABLE Students" + 
                         "(ID number, FirstName varchar(255)," +
                         " LastName varchar(255), " + 
                         "DegreeStatus varchar(255), Major varchar(255))");
        
         System.out.println("Created Students table");
         
         stmt.close();
         con.close();
        }
       // detect problems interacting with the database
      catch ( SQLException sqlException ) {
         JOptionPane.showMessageDialog( null, 
            sqlException.getMessage(), "Database Error",
            JOptionPane.ERROR_MESSAGE );
         
         System.exit( 1 );
      }//end catch block
      
      // detect problems loading database driver
      catch ( ClassNotFoundException classNotFound ) {
         JOptionPane.showMessageDialog( null, 
            classNotFound.getMessage(), "Driver Not Found",
            JOptionPane.ERROR_MESSAGE );

         System.exit( 1 );
      }//end catch block
        
   }//end createTable()

    
//this method accepts the student data as input and stores it to the database 
    public void storeRecord(int id, String fName, String lName, String degStat, String maj){
       
        try {
         
             // load database driver class
         Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

           
         // connect to database
         Connection con = DriverManager.getConnection(filePath);
         
         Statement stmt = con.createStatement();
         //this Insert statement puts student info in the database
         stmt.executeUpdate("INSERT INTO Students VALUES ("+id+",'"+fName+"','" +lName+"','" +degStat+"','"+maj+"')");
         
         
         stmt.close();
         con.close();
        }//end try
        catch(Exception e) 
        {
                e.printStackTrace();
        }//end catch

    }//end storeRecord()
      
    public StudentRecord[] getQueryData ()
    {
        StudentRecord studentArray[] = new StudentRecord[20];
        int numStudents = 0;
        
        try {
             // load database driver class
         Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

           
         // connect to database
         Connection con = DriverManager.getConnection(filePath);
         
         Statement stmt = con.createStatement();

          ResultSet rs = stmt.executeQuery("SELECT * from Students");

          while (rs.next())
          {
              String rsFName = rs.getString("FirstName");
              String rsLName = rs.getString("LastName");
              String rsDegreeStat = rs.getString("DegreeStatus");
              String rsMajor = rs.getString("Major");

              studentArray[numStudents] = new StudentRecord(numStudents, rsFName, rsLName, rsDegreeStat, rsMajor);
              numStudents++;
              System.out.println(rsFName + " " + rsLName);
          }

          stmt.close();

          con.close();

       }
       // detect problems interacting with the database
      catch ( SQLException sqlException ) {
         JOptionPane.showMessageDialog( null, 
            sqlException.getMessage(), "Database Error",
            JOptionPane.ERROR_MESSAGE );
         
         System.exit( 1 );
      }
      
      // detect problems loading database driver
      catch ( ClassNotFoundException classNotFound ) {
         JOptionPane.showMessageDialog( null, 
            classNotFound.getMessage(), "Driver Not Found",
            JOptionPane.ERROR_MESSAGE );

         System.exit( 1 );
      }      
       finally{
           return studentArray;
       }
        

   }
}// end Database class
    

